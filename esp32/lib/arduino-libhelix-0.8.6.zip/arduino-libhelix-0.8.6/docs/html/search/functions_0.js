var searchData=
[
  ['allocatedecoder_30',['allocateDecoder',['../classlibhelix_1_1_a_a_c_decoder_helix.html#ac64dd8567d6e2340588f8dfdfc3919e3',1,'libhelix::AACDecoderHelix::allocateDecoder()'],['../classlibhelix_1_1_common_helix.html#ad2b7a3c93331a0deb2dbd267d39b66c8',1,'libhelix::CommonHelix::allocateDecoder()'],['../classlibhelix_1_1_m_p3_decoder_helix.html#abd913291e8a386de2f59f833d64f09dd',1,'libhelix::MP3DecoderHelix::allocateDecoder()']]],
  ['audioinfo_31',['audioInfo',['../classlibhelix_1_1_a_a_c_decoder_helix.html#a25c720a79d70bf35da7405442686512d',1,'libhelix::AACDecoderHelix::audioInfo()'],['../classlibhelix_1_1_m_p3_decoder_helix.html#a5d2e73af46a007b7f672595baa9e36a6',1,'libhelix::MP3DecoderHelix::audioInfo()']]]
];
